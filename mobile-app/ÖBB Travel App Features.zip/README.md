
  # ÖBB Travel App Features

  This is a code bundle for ÖBB Travel App Features. The original project is available at https://www.figma.com/design/CXeosZRACsA5k1JbSxtIQL/%C3%96BB-Travel-App-Features.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  