import { useState } from 'react';
import { Home, Search, Ticket, User, Settings } from 'lucide-react';
import { HomeScreen } from './components/HomeScreen';
import { SearchScreen } from './components/SearchScreen';
import { TicketsScreen } from './components/TicketsScreen';
import { ProfileScreen } from './components/ProfileScreen';
import obbLogo from 'figma:asset/6b1636309459a55a94c669b9380ad24589cae787.png';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'search' | 'tickets' | 'profile'>('home');

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen />;
      case 'search':
        return <SearchScreen />;
      case 'tickets':
        return <TicketsScreen />;
      case 'profile':
        return <ProfileScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white text-gray-900 p-4 shadow-lg border-b-4 border-red-600">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={obbLogo} alt="ÖBB Logo" className="h-10" />
          </div>
          <Settings className="w-6 h-6 cursor-pointer text-gray-700" />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {renderScreen()}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-200 shadow-lg">
        <div className="max-w-6xl mx-auto flex justify-around">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center gap-1 p-4 transition-colors ${
              activeTab === 'home' ? 'text-red-600' : 'text-gray-500'
            }`}
          >
            <Home className="w-6 h-6" />
            <span className="text-xs">Inicio</span>
          </button>
          <button
            onClick={() => setActiveTab('search')}
            className={`flex flex-col items-center gap-1 p-4 transition-colors ${
              activeTab === 'search' ? 'text-red-600' : 'text-gray-500'
            }`}
          >
            <Search className="w-6 h-6" />
            <span className="text-xs">Buscar</span>
          </button>
          <button
            onClick={() => setActiveTab('tickets')}
            className={`flex flex-col items-center gap-1 p-4 transition-colors ${
              activeTab === 'tickets' ? 'text-red-600' : 'text-gray-500'
            }`}
          >
            <Ticket className="w-6 h-6" />
            <span className="text-xs">Entradas</span>
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center gap-1 p-4 transition-colors ${
              activeTab === 'profile' ? 'text-red-600' : 'text-gray-500'
            }`}
          >
            <User className="w-6 h-6" />
            <span className="text-xs">Perfil</span>
          </button>
        </div>
      </nav>
    </div>
  );
}